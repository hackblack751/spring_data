package org.huy.test_maven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestMavenApplication.class, args);
	}

}
